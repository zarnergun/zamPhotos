package com.zam.photos

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val database = Database(this)

        val user = database.getUsersCount()

        if(user > 0) {
            button.text = "profil"
            val intent = Intent(this, ProfileActivity::class.java)
            startActivity(intent)
        }
        else {
            button.text = "login"
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }
    }

}