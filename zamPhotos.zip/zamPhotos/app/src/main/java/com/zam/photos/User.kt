package com.zam.photos

data class User( val pseudo: String,
                 val email : String,
                 val pic : String)